<?php
$conn=mysqli_connect('localhost','root','','ajax');
$sql='select * from users';

header('content-type:application/json');

$data=mysqli_fetch_all(mysqli_query($conn,$sql),MYSQLI_ASSOC);

print_r(json_encode($data));