<?php
$conn=mysqli_connect('localhost','root','','ajax');

$name=$_REQUEST['myid'];

$sql="delete from users where id='$name'";

if(mysqli_query($conn,$sql))
        echo true;
else
        echo false;